#Lo aconsejable es que los archivos se guarden paquetes, basicamente son carpetas que contienen archivos
#py con modulos relacionados entre si. De esta forma nos permite organizar.
#Para que el interprete de python entienda que una carpeta es un paquete, debe contener un archivo extension
#.py con el nombre __init__
#Veremos que dentro de la carpeta que funcione como paquete, al hacer este archivo se generara una carpeta
#llamada pycache