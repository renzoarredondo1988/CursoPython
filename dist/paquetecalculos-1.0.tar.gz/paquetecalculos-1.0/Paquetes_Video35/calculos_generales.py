def sumar(op1,op2):
    print ("El resutado de la suma es ",op1+op2)

def restar(op1,op2):
    print ("El resutado de la resta es ",op1-op2)

def multiplicar(op1,op2):
    print ("El resutado de la multiplicacion es ",op1*op2)


def dividir(dividendo,divisor):
     print("El resutado de la division es ",dividendo/divisor)

def potencia(base, exponente):
    print("El resutado de la potencia es ", base**exponente)

def redondear(numero):
    print("El resutado del redondeo es ", round(numero))