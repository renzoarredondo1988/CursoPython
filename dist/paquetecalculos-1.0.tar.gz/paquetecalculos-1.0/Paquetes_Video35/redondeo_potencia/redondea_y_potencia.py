def potencia(base, exponente):
    print("El resutado de la potencia es ", base**exponente)

def redondear(numero):
    print("El resutado del redondeo es ", round(numero))